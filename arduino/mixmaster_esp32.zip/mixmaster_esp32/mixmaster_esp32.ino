// =============================================================
//  MixMaster Pro — ESP32-S3 Main Sketch
//
//  ARCHITECTURE:
//    Main Server (PC1) ──WiFi HTTP──▶ ESP32-S3 ──USB Serial──▶ Simulator (PC2)
//                       ◀──status POST──         ◀──fake sensors──
//
//  Required libraries (Arduino Library Manager):
//    - ArduinoJson         6.x  by Benoit Blanchon
//    - WebServer (built-in ESP32 Arduino core)
//    - WiFi      (built-in ESP32 Arduino core)
//    - HTTPClient(built-in ESP32 Arduino core)
//    - OneWire            by Paul Stoffregen   (if using real DS18B20)
//    - DallasTemperature  by Miles Burton      (if using real DS18B20)
// =============================================================

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "machine_config.h"
#include "pump_controller.h"

// ── Global machine state ──────────────────────────────────────
String   machineState    = STATE_IDLE;
bool     mixerOn         = false;
bool     coolerOn        = false;
bool     outSolenoidOn   = false;
bool     drainSolenoidOn = false;
bool     waterPumpOn     = false;
String   activeOrderId   = "";

// ── Sensor values (updated from Simulator PC via serial) ──────
float  sensorBowlMm   = BOWL_EMPTY_MM;
float  sensorTempC    = 22.0f;
uint32_t lastSensorMs = 0;

// ── Recipe queue ───────────────────────────────────────────────
struct IngredientJob { uint8_t pumpIdx; float amountMl; };
const int MAX_ING = 6;
IngredientJob recipeQueue[MAX_ING];
int   recipeJobCount   = 0;
int   recipeJobCurrent = 0;

// ── HTTP Server (port 80) ─────────────────────────────────────
WebServer httpServer(MACHINE_HTTP_PORT);

// ── Timing ────────────────────────────────────────────────────
uint32_t lastActuatorSendMs = 0;
uint32_t lastStatusPostMs   = 0;
uint32_t cleanMixStartMs    = 0;

// ── Serial RX buffer ─────────────────────────────────────────
char    rxBuf[512];
uint16_t rxLen = 0;

// =============================================================
//  OUTPUT HELPERS
// =============================================================
void setMixer(bool on)        { mixerOn = on;        ledcWrite(MIXER_PIN, on ? MIXER_SPEED : 0); }
void setCooler(bool on)       { coolerOn = on;        digitalWrite(COOLER_PIN,        on?HIGH:LOW); }
void setOutSolenoid(bool on)  { outSolenoidOn = on;   digitalWrite(OUT_SOLENOID_PIN,  on?HIGH:LOW); }
void setDrainSolenoid(bool on){ drainSolenoidOn = on; digitalWrite(DRAIN_SOLENOID_PIN,on?HIGH:LOW); }
void setWaterPump(bool on)    { waterPumpOn = on;     digitalWrite(WATER_PUMP_PIN,    on?HIGH:LOW); }

void allOff() {
  pump_stop_all(); setMixer(false); setCooler(false);
  setOutSolenoid(false); setDrainSolenoid(false); setWaterPump(false);
  machineState = STATE_IDLE;
}

// =============================================================
//  SENSOR HELPERS (from simulator serial OR real HC-SR04)
// =============================================================
float bowl_getMl() {
  float pct = constrain(
    (float)(BOWL_EMPTY_MM - sensorBowlMm) / (float)(BOWL_EMPTY_MM - BOWL_FULL_MM),
    0.0f, 1.0f);
  return pct * BOWL_CAPACITY_ML;
}
bool bowl_isEmpty()  { return sensorBowlMm >= (BOWL_EMPTY_MM - 10); }
bool temp_atTarget() { return fabs(sensorTempC - TARGET_TEMP_C) <= TEMP_TOLERANCE; }

// =============================================================
//  SERIAL → SIMULATOR PC
//  Sends actuator states; receives fake sensor data
// =============================================================
void sendActuatorState() {
  uint32_t now = millis();
  if (now - lastActuatorSendMs < ACTUATOR_SEND_INTERVAL) return;
  lastActuatorSendMs = now;

  StaticJsonDocument<384> doc;
  doc["type"]  = "actuator";
  doc["state"] = machineState;
  doc["ts"]    = now;
  JsonArray pumps = doc.createNestedArray("pumps");
  JsonArray prog  = doc.createNestedArray("pump_progress");
  for (int i = 0; i < NUM_PUMPS; i++) {
    pumps.add(pump_isActive(i));
    prog.add((int)(pump_getProgress(i) * 100));
  }
  doc["mixer_on"]       = mixerOn;
  doc["cooler_on"]      = coolerOn;
  doc["out_solenoid"]   = outSolenoidOn;
  doc["drain_solenoid"] = drainSolenoidOn;
  doc["water_pump"]     = waterPumpOn;
  if (activeOrderId.length() > 0) doc["order_id"] = activeOrderId;

  serializeJson(doc, Serial);
  Serial.println();
}

void processSerialSensor(const char* json) {
  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, json)) return;
  if (strcmp(doc["type"] | "", "sensor") != 0) return;
  sensorBowlMm = doc["bowl_level_mm"] | sensorBowlMm;
  sensorTempC  = doc["temp_c"]        | sensorTempC;
  lastSensorMs = millis();
}

void readSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (rxLen > 0) { rxBuf[rxLen] = '\0'; processSerialSensor(rxBuf); rxLen = 0; }
    } else if (rxLen < sizeof(rxBuf)-1) { rxBuf[rxLen++] = c; }
  }
}

// =============================================================
//  HTTP → MAIN SERVER (status callback every 2s)
// =============================================================
void postStatusToServer() {
  uint32_t now = millis();
  if (now - lastStatusPostMs < STATUS_POST_INTERVAL_MS) return;
  if (WiFi.status() != WL_CONNECTED) return;
  lastStatusPostMs = now;

  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/machine/status";
  http.begin(url);
  http.addHeader("Content-Type","application/json");

  StaticJsonDocument<256> doc;
  doc["state"]         = machineState;
  doc["bowl_level_ml"] = (int)bowl_getMl();
  doc["temp_c"]        = (float)((int)(sensorTempC * 10)) / 10.0;
  doc["order_id"]      = activeOrderId;
  doc["ip"]            = WiFi.localIP().toString();
  String body; serializeJson(doc, body);
  http.POST(body);
  http.end();
}

// =============================================================
//  HTTP SERVER HANDLERS (main server → ESP32)
// =============================================================
void handleStartRecipe() {
  if (!httpServer.hasArg("plain")) {
    httpServer.send(400, "application/json", "{\"error\":\"No body\"}");
    return;
  }
  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, httpServer.arg("plain"))) {
    httpServer.send(400, "application/json", "{\"error\":\"JSON parse error\"}");
    return;
  }

  allOff();
  activeOrderId = doc["order_id"] | "";
  recipeJobCount = 0;

  JsonArray ingredients = doc["ingredients"];
  for (JsonObject ing : ingredients) {
    if (recipeJobCount >= MAX_ING) break;
    recipeQueue[recipeJobCount++] = {
      (uint8_t)(int)ing["pump"],
      (float)ing["ml"]
    };
  }

  // Fallback if no ingredients sent: demo 40ml per pump
  if (recipeJobCount == 0) {
    for (int i = 0; i < NUM_PUMPS; i++)
      recipeQueue[recipeJobCount++] = { (uint8_t)i, 40.0f };
  }

  recipeJobCurrent = 0;
  machineState = STATE_FILLING;
  pump_dispense(recipeQueue[0].pumpIdx, recipeQueue[0].amountMl);

  httpServer.send(200, "application/json", "{\"ok\":true,\"state\":\"FILLING\"}");
}

void handleStop() {
  allOff();
  activeOrderId = "";
  httpServer.send(200, "application/json", "{\"ok\":true}");
}

void handleStartClean() {
  allOff();
  machineState = STATE_CLEAN_FILL;
  setWaterPump(true);
  httpServer.send(200, "application/json", "{\"ok\":true,\"state\":\"CLEAN_FILL\"}");
}

void handleSetCal() {
  if (!httpServer.hasArg("plain")) { httpServer.send(400); return; }
  StaticJsonDocument<64> doc;
  deserializeJson(doc, httpServer.arg("plain"));
  int   idx   = doc["pump"]      | -1;
  float ms_ml = doc["ms_per_ml"] | 0.0f;
  if (idx >= 0 && idx < NUM_PUMPS && ms_ml > 0) {
    pump_setCalibration(idx, ms_ml);
    httpServer.send(200, "application/json", "{\"ok\":true}");
  } else { httpServer.send(400, "application/json", "{\"error\":\"bad params\"}"); }
}

void handleStatus() {
  StaticJsonDocument<256> doc;
  doc["state"]         = machineState;
  doc["bowl_level_ml"] = (int)bowl_getMl();
  doc["bowl_level_mm"] = (int)sensorBowlMm;
  doc["temp_c"]        = sensorTempC;
  doc["order_id"]      = activeOrderId;
  doc["ip"]            = WiFi.localIP().toString();
  for (int i = 0; i < NUM_PUMPS; i++) {
    String k = "pump" + String(i+1);
    doc[k] = pump_isActive(i);
  }
  String out; serializeJson(doc, out);
  httpServer.send(200, "application/json", out);
}

// =============================================================
//  STATE MACHINE
// =============================================================
void stateMachine_update() {
  if (machineState == STATE_FILLING) {
    if (!pump_isActive(recipeQueue[recipeJobCurrent].pumpIdx)) {
      recipeJobCurrent++;
      if (recipeJobCurrent >= recipeJobCount) {
        machineState = STATE_MIXING;
        setMixer(true); setCooler(true);
      } else {
        pump_dispense(recipeQueue[recipeJobCurrent].pumpIdx,
                      recipeQueue[recipeJobCurrent].amountMl);
      }
    }
  } else if (machineState == STATE_MIXING) {
    if (temp_atTarget()) {
      machineState = STATE_SERVING;
      setMixer(false); setCooler(false); setOutSolenoid(true);
    }
  } else if (machineState == STATE_SERVING) {
    if (sensorBowlMm >= (BOWL_EMPTY_MM - 20) || bowl_isEmpty()) {
      setOutSolenoid(false);
      activeOrderId = "";
      machineState = STATE_IDLE;
    }
  } else if (machineState == STATE_CLEAN_FILL) {
    if (bowl_getMl() >= CLEAN_FILL_ML) {
      setWaterPump(false); machineState = STATE_CLEAN_MIX;
      setMixer(true); cleanMixStartMs = millis();
    }
  } else if (machineState == STATE_CLEAN_MIX) {
    if (millis() - cleanMixStartMs >= (uint32_t)CLEAN_MIX_TIME_S * 1000UL) {
      setMixer(false); machineState = STATE_CLEAN_DRAIN; setDrainSolenoid(true);
    }
  } else if (machineState == STATE_CLEAN_DRAIN) {
    if (bowl_isEmpty()) {
      setDrainSolenoid(false); machineState = STATE_IDLE;
    }
  }
}

// =============================================================
//  SETUP & LOOP
// =============================================================
void setup() {
  Serial.begin(SERIAL_BAUD);

  // Output pins
  pinMode(COOLER_PIN,         OUTPUT);
  pinMode(OUT_SOLENOID_PIN,   OUTPUT);
  pinMode(WATER_PUMP_PIN,     OUTPUT);
  pinMode(DRAIN_SOLENOID_PIN, OUTPUT);
  ledcAttach(MIXER_PIN, MIXER_FREQ, MIXER_RESOLUTION);
  pumpController_init();
  allOff();

  // WiFi
  Serial.print("{\"type\":\"boot\",\"msg\":\"Connecting WiFi...\"}");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  uint32_t wStart = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wStart < WIFI_TIMEOUT_MS) {
    delay(250);
  }

  if (WiFi.status() == WL_CONNECTED) {
    String ip = WiFi.localIP().toString();
    Serial.println();
    StaticJsonDocument<128> doc;
    doc["type"] = "boot"; doc["msg"] = "WiFi OK"; doc["ip"] = ip;
    serializeJson(doc, Serial); Serial.println();

    // HTTP server routes
    httpServer.on("/start-recipe", HTTP_POST, handleStartRecipe);
    httpServer.on("/stop",         HTTP_POST, handleStop);
    httpServer.on("/start-clean",  HTTP_POST, handleStartClean);
    httpServer.on("/set-cal",      HTTP_POST, handleSetCal);
    httpServer.on("/status",       HTTP_GET,  handleStatus);
    httpServer.begin();
  } else {
    Serial.println("{\"type\":\"boot\",\"msg\":\"WiFi FAILED — serial-only mode\"}");
  }
}

void loop() {
  httpServer.handleClient();   // serve HTTP requests
  readSerial();                // read fake sensor data from simulator
  pumpController_update();     // check pump timers
  stateMachine_update();       // advance state machine
  sendActuatorState();         // send actuator states to simulator via serial
  postStatusToServer();        // send status to main server via WiFi
}
