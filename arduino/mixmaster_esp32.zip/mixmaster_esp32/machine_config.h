#pragma once

// =============================================================
//  MixMaster Pro — Machine Configuration  (ESP32-S3)
// =============================================================

// ── Serial (to Simulator PC via USB) ─────────────────────────
#define SERIAL_BAUD            115200
#define ACTUATOR_SEND_INTERVAL  200   // ms between actuator state sends
#define SENSOR_TIMEOUT_MS      2000   // ms before treating sensor as stale

// ── WiFi (edit before flashing) ───────────────────────────────
#define WIFI_SSID     "Chandeepa"
#define WIFI_PASSWORD "11111111"
#define WIFI_TIMEOUT_MS  15000   // max time to connect

// ── Main Server callback ───────────────────────────────────────
// The ESP32 POSTs its status back to this address every 2 seconds
#define SERVER_IP    "10.32.130.107"   // <- Change to your PC 1 IP
#define SERVER_PORT   3000
#define STATUS_POST_INTERVAL_MS  2000

// ── ESP32 HTTP server port ────────────────────────────────────
#define MACHINE_HTTP_PORT  80

// ── Pump GPIO Pins (ON/OFF timing pumps — active HIGH) ────────
// ESP32-S3 safe GPIOs (avoid 0, 19, 20, 26–32, 43, 44)
#define PUMP_1_PIN    1
#define PUMP_2_PIN    2
#define PUMP_3_PIN    3
#define PUMP_4_PIN    4
#define PUMP_5_PIN    5
#define PUMP_6_PIN    6
#define NUM_PUMPS     6

// Pump calibration: milliseconds per 1 ml
// Tune with Developer Panel — these are defaults
float PUMP_MS_PER_ML[NUM_PUMPS] = {
  320.0f, 320.0f, 320.0f, 320.0f, 320.0f, 320.0f
};

// ── Ultrasonic Sensor (HC-SR04) ───────────────────────────────
#define ULTRASONIC_TRIG_PIN   7
#define ULTRASONIC_ECHO_PIN   8
#define BOWL_EMPTY_MM        280
#define BOWL_FULL_MM          30
#define BOWL_CAPACITY_ML     500
#define CUP_EMPTY_MM         180
#define CUP_OVERFLOW_MM       20

// ── Temperature Sensor (DS18B20) ──────────────────────────────
#define TEMP_SENSOR_PIN    9
#define TARGET_TEMP_C      8.0f
#define TEMP_TOLERANCE     0.5f

// ── Mixer Motor (PWM) ─────────────────────────────────────────
#define MIXER_PIN          10
#define MIXER_FREQ         5000
#define MIXER_RESOLUTION   8
#define MIXER_SPEED        180

// ── Other outputs ─────────────────────────────────────────────
#define COOLER_PIN         11
#define OUT_SOLENOID_PIN   12
#define WATER_PUMP_PIN     13
#define DRAIN_SOLENOID_PIN 14

// ── Cleaning ──────────────────────────────────────────────────
#define CLEAN_FILL_ML      400
#define CLEAN_MIX_TIME_S    30

// ── State strings ─────────────────────────────────────────────
#define STATE_IDLE        "IDLE"
#define STATE_FILLING     "FILLING"
#define STATE_MIXING      "MIXING"
#define STATE_SERVING     "SERVING"
#define STATE_CLEAN_FILL  "CLEAN_FILL"
#define STATE_CLEAN_MIX   "CLEAN_MIX"
#define STATE_CLEAN_DRAIN "CLEAN_DRAIN"
#define STATE_ERROR       "ERROR"
