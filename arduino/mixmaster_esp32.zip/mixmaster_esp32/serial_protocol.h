#pragma once
#include <Arduino.h>
#include <ArduinoJson.h>
#include "machine_config.h"
#include "pump_controller.h"
#include "sensor_manager.h"

// =============================================================
//  Serial Protocol — JSON line-based command/telemetry bridge
//  PC→ESP32 commands + ESP32→PC telemetry (every 200ms)
// =============================================================

// Forward declarations of state machine functions (in main .ino)
extern String  machineState;
extern bool    mixerOn;
extern bool    coolerOn;
extern bool    outSolenoidOn;
extern bool    drainSolenoidOn;
extern bool    waterPumpOn;
extern void    cmd_startRecipe(const char* recipeId);
extern void    cmd_stopAll();
extern void    cmd_startClean();

static uint32_t _lastTelemetryMs = 0;
static char     _rxBuffer[512];
static uint16_t _rxLen = 0;

// ── Telemetry: ESP32 → PC ─────────────────────────────────────
void serial_sendTelemetry() {
  uint32_t now = millis();
  if (now - _lastTelemetryMs < TELEMETRY_INTERVAL_MS) return;
  _lastTelemetryMs = now;

  StaticJsonDocument<512> doc;
  doc["type"] = "telemetry";
  doc["ts"]   = now;
  doc["state"] = machineState;
  doc["bowl_level_mm"] = (int)ultrasonic_getMm();
  doc["bowl_level_ml"] = (int)bowl_getMl();
  doc["bowl_temp_c"]   = (float)((int)(temp_getC() * 10)) / 10.0;
  doc["mixer_on"]      = mixerOn;
  doc["cooler_on"]     = coolerOn;
  doc["out_solenoid"]  = outSolenoidOn;
  doc["drain_solenoid"]= drainSolenoidOn;
  doc["water_pump"]    = waterPumpOn;

  JsonArray pumps = doc.createNestedArray("pumps");
  for (int i = 0; i < NUM_PUMPS; i++) pumps.add(pump_isActive(i));

  JsonArray progress = doc.createNestedArray("pump_progress");
  for (int i = 0; i < NUM_PUMPS; i++) progress.add((int)(pump_getProgress(i) * 100));

  serializeJson(doc, Serial);
  Serial.println();  // newline terminates each JSON message
}

// ── Acknowledge helper ─────────────────────────────────────────
void serial_ack(const char* cmd, bool ok, const char* msg = "") {
  StaticJsonDocument<128> doc;
  doc["type"] = "ack";
  doc["cmd"]  = cmd;
  doc["ok"]   = ok;
  if (strlen(msg) > 0) doc["msg"] = msg;
  serializeJson(doc, Serial);
  Serial.println();
}

// ── Command dispatcher: PC → ESP32 ────────────────────────────
void serial_processCommand(const char* json) {
  StaticJsonDocument<256> doc;
  DeserializationError err = deserializeJson(doc, json);
  if (err) {
    serial_ack("unknown", false, "JSON parse error");
    return;
  }

  const char* cmd = doc["cmd"] | "";

  if (strcmp(cmd, "START_RECIPE") == 0) {
    const char* rid = doc["recipe_id"] | "";
    cmd_startRecipe(rid);
    serial_ack(cmd, true, rid);

  } else if (strcmp(cmd, "STOP") == 0) {
    cmd_stopAll();
    serial_ack(cmd, true);

  } else if (strcmp(cmd, "PRIME_PUMP") == 0) {
    int   idx = doc["pump"]        | -1;
    float dur = doc["duration_ms"] | 500.0f;
    if (idx >= 0 && idx < NUM_PUMPS) {
      pump_run_ms(idx, (uint32_t)dur);
      serial_ack(cmd, true);
    } else {
      serial_ack(cmd, false, "bad pump index");
    }

  } else if (strcmp(cmd, "SET_PUMP_CAL") == 0) {
    int   idx     = doc["pump"]      | -1;
    float msPerMl = doc["ms_per_ml"] | 0.0f;
    if (idx >= 0 && idx < NUM_PUMPS && msPerMl > 0) {
      pump_setCalibration(idx, msPerMl);
      serial_ack(cmd, true);
    } else {
      serial_ack(cmd, false, "bad params");
    }

  } else if (strcmp(cmd, "START_CLEAN") == 0) {
    cmd_startClean();
    serial_ack(cmd, true);

  } else if (strcmp(cmd, "SET_TARGET_TEMP") == 0) {
    // (stored in RAM only — not persisted to flash in this version)
    serial_ack(cmd, true, "temp noted");

  } else if (strcmp(cmd, "PING") == 0) {
    serial_ack("PING", true, "PONG");

  } else {
    serial_ack(cmd, false, "unknown command");
  }
}

// ── Read incoming bytes, dispatch on newline ───────────────────
void serial_update() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (_rxLen > 0) {
        _rxBuffer[_rxLen] = '\0';
        serial_processCommand(_rxBuffer);
        _rxLen = 0;
      }
    } else if (_rxLen < sizeof(_rxBuffer) - 1) {
      _rxBuffer[_rxLen++] = c;
    }
  }
}
